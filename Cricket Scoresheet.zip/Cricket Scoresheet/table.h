void updatedetail();
void table();
void gotoxy(int x,int y);
void new_sheet(void);
void fillchart(void);
void enterchoice(void);
void fileprint(void);
void updatesheet(void);
void check_list();
void fileview();
void close();
void menu();
struct date
{
	int d,m,y;
};
struct
{
	char fteam[20],steam[20],comp[20],venu[20];
	int ovr;
	struct date play;
}gamedetails;
struct
{
	char bowler[20];
	int bowlrun,ball,balover,wicket;
}bowlteam[6];
struct
{
	
	char batsman[20];
	int batrun;
	int balplay;
	
	
} bateam[11];
int m,choice,w=0,o=0;
char fname[20],updfname[20],cfname[20],ofname[20];
void new_sheet(void)
{
	FILE *listf;
	system("cls");
	system("COLOR A0");
	printf("\n\n\n\n\n\t\t-----> Enter the name for file (with .txt extension): ");
	scanf("%s",fname);
	listf=fopen("record.txt","a+");
	while(fscanf(listf,"%s\n",updfname)!=EOF)
	{
		if(strcmpi(fname,updfname)==0)
		{
			printf("\n\n\tFile Already exist ");
			fordelay(1000000000);
			system("cls");
			printf("\n\n\n\n\n\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2 CHECK MATCH LIST \xB2\xB2\xB2\xB2\xB2");
			fordelay(1000000000);
			system("cls");
			menu();
		}
	}
	fprintf(listf,"%s\n",fname);
	fclose(listf);
	system("cls");
	table();
	fillchart();
	enterchoice();
	
	
}
void fillchart()
{
	gotoxy (15,0);
	scanf(" %[^\n]s",gamedetails.comp);
	gotoxy (50,0);
	scanf(" %[^\n]s",gamedetails.venu);
	gotoxy (13,2);
	scanf(" %[^\n]s",gamedetails.fteam);
	gotoxy (54,2);
	scanf(" %[^\n]s",gamedetails.steam);
	gotoxy (8,4);
	scanf("%d/%d/%d",&gamedetails.play.d,&gamedetails.play.m,&gamedetails.play.y);
	gotoxy (50,4);
	scanf("%d",&gamedetails.ovr);
	
	for (m=0;m<=9;m++)
	{
		gotoxy (5,8+m);
		scanf(" %[^\n]s",&bateam[m].batsman);
		gotoxy (44,8+m);
		printf("0");
		bateam[m].batrun=0;
		gotoxy (54,8+m);
		printf("0");
		bateam[m].balplay=0;
	}
	for (m=0;m<=4;m++)
	{
		gotoxy (5,21+m);
		scanf(" %[^\n]s",&bowlteam[m].bowler);
		gotoxy (44,21+m);
		printf("0");
		bowlteam[m].bowlrun=0;
		gotoxy (52,21+m);
		printf("0");
		bowlteam[m].ball=0;
		gotoxy (60,21+m);
		printf("0");
		bowlteam[m].balover=0;
		gotoxy (68,21+m);
		printf("0");
		bowlteam[m].wicket=0;
	}
	gotoxy (0,27);
	for (m=0;m<=85;m++)
	{
		printf("%c",205);
	}
	printf("\n\xB4\xB4\xB4\xB4 Play Match \xB4\xB4\xB4\xB4");
	printf("\t---->\t|0|1|2|3|4|6|\t\t|7-Wide|8-Out|9-Exit|");
	printf("\nEnter: ");	
}

void enterchoice()
{
	if(o>4)
	{
		o=0;
	}
	if(w>9)
	{
		fileprint();
		system("cls");
		printf("\n\n\n\n\n\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2 GAME OVER \xB2\xB2\xB2\xB2\xB2");
		getch();
		system("cls");
		menu();
	}
	gotoxy (6,29);
	scanf("%d",&choice);
	if (choice==0)
	{
		bowlteam[o].ball++;
		bateam[o].balplay++;
		if (((bowlteam[o].ball/6)>=1) && ((bowlteam[o].ball%6)==0))
		{
			bowlteam[o].balover++;
			o++;
		}
		updatesheet();
		enterchoice();
	}
	else if (choice==1)
	{
		bowlteam[o].ball++;
		bateam[w].balplay++;
		bateam[w].batrun+=1;
		bowlteam[o].bowlrun+=1;
		if (((bowlteam[o].ball/6)>=1) && ((bowlteam[o].ball%6)==0))
		{
			bowlteam[o].balover++;
			o++;
		}
		updatesheet();
		enterchoice();
	}
	else if (choice==2)
	{
		bowlteam[o].ball++;
		bateam[w].balplay++;
		bateam[w].batrun+=2;
		bowlteam[o].bowlrun+=2;
		if (((bowlteam[o].ball/6)>=1) && ((bowlteam[o].ball%6)==0))
		{
			bowlteam[o].balover++;
			o++;
		}
		updatesheet();
		enterchoice();
	}
	else if (choice==3)
	{
		bowlteam[o].ball++;
		bateam[w].balplay++;
		bateam[w].batrun+=3;
		bowlteam[o].bowlrun+=3;
		if (((bowlteam[o].ball/6)>=1) && ((bowlteam[o].ball%6)==0))
		{
			bowlteam[o].balover++;
			o++;
		}
		updatesheet();
		enterchoice();
	}
	else if (choice==4)
	{
		bowlteam[o].ball++;
		bateam[w].balplay++;
		bateam[w].batrun+=4;
		bowlteam[o].bowlrun+=4;
		if (((bowlteam[o].ball/6)>=1) && ((bowlteam[o].ball%6)==0))
		{
			bowlteam[o].balover++;
			o++;
		}
		updatesheet();
		enterchoice();
	}
	else if (choice==6)
	{
		bowlteam[o].ball++;
		bateam[w].balplay++;
		bateam[w].batrun+=6;
		bowlteam[o].bowlrun+=6;
		if (((bowlteam[o].ball/6)>=1) && ((bowlteam[o].ball%6)==0))
		{
			bowlteam[o].balover++;
			o++;
		}
		updatesheet();
		enterchoice();
	}
	else if (choice==7)
	{
		bateam[w].batrun++;
		bowlteam[o].bowlrun++;
		updatesheet();
		enterchoice();
	}
	else if (choice==8)
	{
		bowlteam[o].ball++;
		bateam[w].balplay++;
		bowlteam[o].wicket++;
		w++;
		if (((bowlteam[o].ball/6)>=1) && ((bowlteam[o].ball%6)==0))
		{
			bowlteam[o].balover++;
			o++;
		}
		updatesheet();
		enterchoice();
	}
	else if (choice==9)
	{
		fileprint();
		system("cls");
		printf("\n\n\n\n\n\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2 GAME OVER \xB2\xB2\xB2\xB2\xB2");
		getch();
		system("cls");
		menu();
	}
	else
	{
		enterchoice();
	}
}
void updatesheet(void)
{
	for (m=0;m<=9;m++)
	{
		gotoxy (5,8+m);
		printf("%s",&bateam[m].batsman);
		gotoxy (44,8+m);
		printf("%d",bateam[m].batrun);
		gotoxy (54,8+m);
		printf("%d",bateam[m].balplay);
	}
	for (m=0;m<=4;m++)
	{
		gotoxy (5,21+m);
		printf("%s",&bowlteam[m].bowler);
		gotoxy (44,21+m);
		printf("%d",bowlteam[m].bowlrun);
		gotoxy (52,21+m);
		printf("%d",bowlteam[m].ball);
		gotoxy (60,21+m);
		printf("%d",bowlteam[m].balover);
		gotoxy (68,21+m);
		printf("%d",bowlteam[m].wicket);
	}
}
void updatedetail()
{
	gotoxy (15,0);
	printf("%s",gamedetails.comp);
	gotoxy (50,0);
	printf("%s",gamedetails.venu);
	gotoxy (13,2);
	printf("%s",gamedetails.fteam);
	gotoxy (54,2);
	printf("%s",gamedetails.steam);
	gotoxy (8,4);
	printf("%d/%d/%d",gamedetails.play.d,gamedetails.play.m,gamedetails.play.y);
	gotoxy (50,4);
	printf("%d",gamedetails.ovr);
}
void fileprint(void)
{
	FILE *updf;
	updf=fopen(fname,"a+");
	fwrite(&gamedetails,sizeof(gamedetails),1,updf);
	fwrite(&bateam,sizeof(bateam),11,updf);
	fwrite(&bowlteam,sizeof(bowlteam),6,updf);
	fclose(updf);
}
void fileview()
{
	FILE *updf,*oldf;
	int test=1,cjoice=0;
	printf("\n\n\t\t\tEnter file name: ");
	scanf("%s",cfname);
	oldf=fopen("record.txt","r");
	while(fscanf(oldf,"%s\n",ofname)!=EOF)
	{
		if(strcmpi(ofname,cfname)==0)
		{
			test=0;
		}
	}
	if (test==0)
	{
		system("cls");
		updf=fopen(cfname,"a+");
		fread(&gamedetails,sizeof(gamedetails),1,updf);
		fread(&bateam,sizeof(bateam),11,updf);
		fread(&bowlteam,sizeof(bowlteam),6,updf);
		table();
		updatedetail();
		updatesheet();
		printf("\n\n\n\tPress 1 for Main menu or Press 0 to exit: ");
		scanf("%d",&cjoice);
		if (cjoice==1)
		{
			fclose(updf);
			fclose(oldf);
			system("cls");
			menu();
		}
		else if (cjoice==0)
		{
			fclose(updf);
			fclose(oldf);
			system("cls");
			close();
		}
		
	}
	else if (test!=0)
	{
		printf("\n\n\tFile does not exist ");
		fordelay(1000000000);
		fclose(oldf);
		system("cls");
		printf("\n\n\n\n\n\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2 CHECK MATCH LIST \xB2\xB2\xB2\xB2\xB2");
		fordelay(100000000);
		system("cls");
		menu();	
	}
}
void check_list()
{
	system("COLOR B0");
	FILE *of;
	int z=0;
	char gname[20];
	of=fopen("record.txt","r");
	printf("\n\n\t\xB2\xB2\xB2\xB2\xB2 GAME LIST \xB2\xB2\xB2\xB2\xB2\n");
	while(fscanf(of,"%s\n",gname)!=EOF)
	{
		z++;
		printf("\n%d. %s",z,gname);
	}
	getch();
	system("cls");
	menu();
}
void gotoxy(int x, int y)
{
	COORD coord;
	coord.X=x;
	coord.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}
void table()
{
	int i;
	printf("| Competition:\t\t\t\t|| Venue: \t\t\t\t|\n");
	for (i=0;i<=80;i++)
	{
		printf("%c",205);
	}
	printf("\n| Home team: \t\t\t\t|| Away team: \t\t\t\t|\n");
	for (i=0;i<=80;i++)
	{
		printf("%c",205);
	}
	printf("\n| Date: \t\t\t\t|| Overs: \t\t\t\t|\n");
	for (i=0;i<=80;i++)
	{
		printf("%c",205);
	}
	printf("\n|    \t\tBatsman \t\t|| Runs     Ball played \t\t|\n");
	for (i=0;i<=80;i++)
	{
		printf("%c",205);
	}
	printf("\n| 1. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 2. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 3. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 4. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 5. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 6. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 7. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 8. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 9. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 10. \t\t\t\t\t||\t\t\t\t\t|\n");
	for (i=0;i<=80;i++)
	{
		printf("%c",205);
	}
	printf("\n|    \t\tBowlers \t\t|| Runs   Balls   Overs   Wicket \t|\n");
	for (i=0;i<=80;i++)
	{
		printf("%c",205);
	}
	printf("\n| 1. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 2. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 3. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 4. \t\t\t\t\t|| \t\t\t\t\t|");
	printf("\n| 5. \t\t\t\t\t|| \t\t\t\t\t|\n");
	for (i=0;i<=80;i++)
	{
		printf("%c",205);
	}
	gotoxy (0,33);
	for (i=0;i<=85;i++)
	{
		printf("%c",205);
	}
}
	
