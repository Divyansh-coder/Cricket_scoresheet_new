#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<windows.h>
#include"welcome.h"
#include"menu.h"
#include"table.h"
main()
{
	welcome();
	system("cls");
	menu();
	return 0;
}
