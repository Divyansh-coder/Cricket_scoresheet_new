void fordelay(int j);
void close(void);
void new_sheet();
void check_list();
void fileview();
void menu()
{
	system("COLOR 1F");
	int i,k,l=7;
	printf("\n\n\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2 MAIN MENU \xB2\xB2\xB2\xB2\xB2\xB2");
	printf("\n\t\t----------------------------------------------");
	printf("\n\t\t\t[1] New Scoresheet.\n\t\t\t[2] View Scoresheet.\n\t\t\t[3] Check match list.\n\t\t\t[4] Exit.");
	printf("\n\t\t----------------------------------------------");
	printf("\n\t\tEnter your choice.");
	scanf("%d",&i);
	switch(i)
	{
		case 1:
			system("cls");
			printf("Loading");
			for(k=0;k<7;k++)
			{
				fordelay(100000000);
				printf(" .");
			}
			new_sheet();
			break;
		case 2:
			system("cls");
			printf("Loading");
			for(k=0;k<7;k++)
			{
				fordelay(100000000);
				printf(" .");
			}
			system("cls");
			system("COLOR 5F");
			fileview();
			break;
		case 3:
			system("cls");
			check_list();
			break;
		case 4:
			system("cls");
			close();
			break;
		default:
			system("cls");
			menu();		
	}
}
void close(void)
{
	printf("\xB2\xB2\xB2\xB2\xB2 Made by Divyansh Garg \xB2\xB2\xB2\xB2\xB2");
}
