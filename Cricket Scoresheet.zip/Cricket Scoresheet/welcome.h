void fordelay(int j);
void welcome(void)
{
	int i=0,j=5,k=0,l=1;
	system("COLOR 4F");
	printf("\n\n\n\t\t\t###############################");
	printf("\n\t\t\t\t   Welcome\n\t\t\t\t      To\n\t\t\t\tCricket Scoresheet");
	printf("\n\t\t\t###############################");
	printf("\n\n\t\tPlease wait");
	printf("\n\t\tLoading");
	for(k=0;k<=l;k++)
	{
		printf("\n\t\t");
		for(i=0;i<=3;i++)
		{
			fordelay(100000000);
			printf("\n\t\t_");
		}
	}
}
void fordelay(int j)
{
	int i,k;
	for(i=0;i<=2*j;i++)
	{
		k=i;
	}
}
